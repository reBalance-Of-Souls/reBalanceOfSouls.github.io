---
name: rebalance-site-conventions
description: "Structure/terminology conventions for the reBalance of Souls patch-notes site (index.html) and the state of the V1.1 patch notes"
metadata: 
  node_type: memory
  type: project
  originSessionId: 470c9873-a15e-4073-91a5-f3c40e0ff87b
---

Berg co-runs "BLEACH reBalance of Souls," a community balance patch for BLEACH: Rebirth of Souls; the site (reBalanceOfSouls.github.io, single index.html, ~12MB due to base64 V1.0 portraits) hosts the patch notes.

Conventions when adding patch content:
- Discord shorthand -> site terms: sp1/sp2 -> "Spiritual Pressure Move 1/2", sig -> "Signature Move", "base and evo" -> [Common], evo -> [Awakening], base -> [Initial Stage], reawakening -> [Reawakening]. FS = Fighting Spirit (but "FS followup" = Flash Step follow-up). lo02/lo03 = Light 2/Light 3, hi02 = Heavy 2, light1_2 = the Light 1 whiff follow-up. Konpaku = the Konpaku damage gauge.
- Tags: .tag-buff/.tag-nerf/.tag-fix/.tag-rework + split .tag-fix-nerf/.tag-fix-buff (half-l/half-r spans) + .tag-reverted. Custom label text in a .tag-buff pill is fine (e.g. OPTIMIZATION, QUALITY OF LIFE).
- Structure: version tabs (.version-nav, panels #panel-v11/#panel-v10), per-character paired divs .cmp-v10 (deltas vs previous patch) and .cmp-vanilla (cumulative vs unmodded game, reverted V1.0 entries marked REVERTED). Compare toggle buttons switch via .show-vanilla class on #panel-v11. A plain .cmp block (no -v10/-vanilla) always shows regardless of toggle - used for the Launcher/Installer entry.
- A char-header can omit .char-portrait-wrap for non-character entries (Launcher & Installer, Reverse Mechanics).
- Portraits live in portraits/*.webp (500x500 crops; "True Shichigo"/tybw-ichigo = TYBW Ichigo). V1.0 keeps embedded base64. New in this session: portraits/shinji.webp, soifon.webp, yhwach.webp were decoded out of the V1.0 base64 imgs and saved as files.
- Credits: Nilsix, Bergen (= Berg), Efra (Shuhei), Meri (Byakuya).

V1.1 state (updated July 2026): the patch is now labelled just "V1.1" - the old "Part 1 / Part 2" split was removed (hero-tag, version tab, patch-banner heading). Panel #panel-v11 now contains: a "System, Reverse & Launcher" section (Launcher/Installer optimization + bugfixes + quick launchers; Yellow Reverse nerf and White Reverse buff), then character adjustments for Byakuya, Uryu, Yamamoto, Yoruichi, Gin, TYBW Ichigo, Dangai Ichigo, Grimmjow, Kisuke, Shuhei, Halibel, plus new entries Shinji (Awakening Kikon/Sakanade rework), Soi Fon (FS to Awakening 6->4.25), and Yhwach (V1.0 SP-gain and Konpaku-count changes reverted).
- Uryu's DP install issue is RESOLVED: SP2 now grants install and fires its arrow only on hit (armored moves count as guarded, no install). The old "Known Issue / arriving in Part 2" note was removed.
- Yamamoto's SP2-vs-grab whiff (a V1.0 Known Issue) is now fixed.
- Byakuya's Senka is now fully non-cancellable (whiff/block/hit) after a later balance pass reversed the hotfix that had restored block/hit cancels.

Gotcha: the working index.html on disk had been truncated mid-base64 at the RENJI portrait (the whole tail - Renji's entry, panel close, footer, version-switch script, </body></html> - was missing). Recovered by splicing `<!-- RENJI -->`..EOF from git HEAD:index.html onto the edited content. If the file ever looks cut off again, check the end for </body></html> and restore the tail from HEAD.
